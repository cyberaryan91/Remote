<?php
#file name : dbconnect.php
#foldername : database 

?>
<?php

$webRoutes['DEFAULT_ROUTE']='/frontend/views/general/home.php';
$webRoutes['404_ERROR_ROUTE']='/frontend/views/error/404.php';

$webRoutes['/'] = '/frontend/views/general/home.php';
$webRoutes['/home'] = '/frontend/views/general/home.php';
$webRoutes['/about-us'] = '/frontend/views/general/about.php';
$webRoutes['/our-product'] = '/frontend/views/general/product.php';
$webRoutes['/video-games'] = '/frontend/views/general/video.php';
$webRoutes['/remote'] = '/frontend/views/general/remot.php';

$webRoutes['/contact-us'] = '/frontend/views/general/contact.php';
$webRoutes['/login'] = '/frontend/views/general/login.php';





  





?>
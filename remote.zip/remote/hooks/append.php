<?php

require_once dirname(__DIR__).'/frontend/layouts/footer.php';

?>
<?php ob_clean(); #it will stop Auto loading from the header ?>
</hr>
<div style="height:auto;width:100%;border:2px solid black;background:white;">
	Welcome to <mark> My Framework.</mark>
	<br/>
	<code>	
		if you want to edit this file, goto <span style='color:red'>/frontend/views/welcome.php </span>.
	</code>
</div>
</hr>
<?php exit; #it wills stop autoloading from the footer. ?>
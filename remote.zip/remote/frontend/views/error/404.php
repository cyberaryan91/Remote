<?php


?>
</hr>
<div style="height:auto;width:100%;border:2px solid black;background:white;box-shadow:2px 2px 5px black;margin-top:10%;border-radius:5px;">
	<center>
	<h1>404, Page Not Found !!!</h1>
	<h4>The Url you searched does not exist,
 	?search=<?php echo basename($_SERVER['REQUEST_URI']); ?></h4>
	
	<a href="#"> Back to Home </a>
	</center>
</div>
</hr>
<?php
define('BASE_URL','http://localhost/remote/');
define('PROJECT_PATH',dirname(__DIR__));

return [
	 'database' => [
		'hostname' => 'localhost',
		'username' => 'root',
		'password'=> '',
		'dbname'=> 'my_db',
		'port'=> 3306
	 ]
];

?>
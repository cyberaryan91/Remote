<?php
#note : in laravel same file is called : kernel.php,boot.php,core.php
#bootstrap : folder : intialisation of the Application.

$config = include_once dirname(__DIR__).'/config/settings.php';
require_once PROJECT_PATH.'/helper/functions.php';

$hostname = $config['database']['hostname'];
$username = $config['database']['username'];
$password = $config['database']['password'];
$dbname = $config['database']['dbname'];
$port = $config['database']['port'];

//include routes file
require_once PROJECT_PATH.'/routes/web-routes.php';
require_once PROJECT_PATH.'/routes/api-routes.php';


?>
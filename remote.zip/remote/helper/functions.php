<?php
/**
* @title : functions.php
* @description : This the Main file where all the ready made functions
*  will be declared.
*
*/

# getBaseURL: It will Return the base_url and will give the new URL.  
if(!function_exists('getBaseURL')){
	
	function getBaseURL($url=''){
		if(empty($url)){
			return BASE_URL;
		}else{
			return BASE_URL.$url;
		}
		
	}
}




?>